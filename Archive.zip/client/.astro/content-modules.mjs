
export default new Map([
["src/content/recipes/dirt-cake.mdx", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fcontent%2Frecipes%2Fdirt-cake.mdx&astroContentModuleFlag=true")],
["src/content/recipes/mud-pie.mdx", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fcontent%2Frecipes%2Fmud-pie.mdx&astroContentModuleFlag=true")],
["src/content/recipes/sandwich.mdx", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fcontent%2Frecipes%2Fsandwich.mdx&astroContentModuleFlag=true")]]);
		